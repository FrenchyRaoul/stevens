module.exports = {
  salt: "$2b$16$06tM4sg4xSGnpH5uyYRtre", //regenerating the salt every time changes the hashes...,
  port: 3000,
  database: "lesperance-nicholai-CS554-Lab1",
  server_url: 'mongodb://localhost:27017',
};